from django.apps import AppConfig


class ContactosConfig(AppConfig):
    name = 'Contactos'